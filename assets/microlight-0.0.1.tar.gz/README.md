microlight.js
=============

*microlight.js* is a micro-library which simplifies reading snippets of source code by highlighting, for any programming language, yet without attaching additional language packages or styles:

![]
(http://asvd.github.io/microlight/microlight-preview-big.png)

For demos and usage guide, refer to https://asvd.github.io/microlight

--

Follow me on twitter: https://twitter.com/asvd0

